<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Karyawan</title>
	<link rel="stylesheet" href="../assets/css/bootstrap.css">
	<link rel="stylesheet" href="../assets/css/header.css" type="text/css">
	<link rel="stylesheet" href="../assets/css/dashboard.css">
	<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #48D1CC;">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="http://localhost/proyek-white-boutique/petugas/index.php">Dashboard <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="http://localhost/proyek-white-boutique/petugas/transaksi.php">Transaksi <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="http://localhost/proyek-white-boutique/petugas/data-barang.php">Barang</a>
				</li>
				<li class="nav-item">
					<a class="nav-link btn btn-danger btn-sm text-white" href="logout.php">Keluar</a>
				</li>
			</ul>
		</div>
</nav>
</html>