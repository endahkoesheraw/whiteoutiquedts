<!-- halo -->
<div class="halo">
	<center>
		<div class="halo-profile-pic">
			<img src="../img/dashboard/profile-pic.png" alt="" style="border-radius: 50%;">
		</div>
		<div class="halo-name">
			<h2> <b>Hai !</b><br /> <?= $_SESSION["user"]; ?></h2>
		</div>
	</center>
</div>
<div class="halo-waves">
	<svg xmlns="../img/dashboard/wave-up.svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,256L26.7,240C53.3,224,107,192,160,192C213.3,192,267,224,320,218.7C373.3,213,427,171,480,176C533.3,181,587,235,640,218.7C693.3,203,747,117,800,106.7C853.3,96,907,160,960,165.3C1013.3,171,1067,117,1120,133.3C1173.3,149,1227,235,1280,256C1333.3,277,1387,235,1413,213.3L1440,192L1440,0L1413.3,0C1386.7,0,1333,0,1280,0C1226.7,0,1173,0,1120,0C1066.7,0,1013,0,960,0C906.7,0,853,0,800,0C746.7,0,693,0,640,0C586.7,0,533,0,480,0C426.7,0,373,0,320,0C266.7,0,213,0,160,0C106.7,0,53,0,27,0L0,0Z"></path>
	</svg>
</div>
<!-- end halo -->