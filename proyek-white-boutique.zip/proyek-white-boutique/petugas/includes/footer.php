<style>
    .bawah {
        position: absolute;
        bottom:0:
        position: absolute;
        bottom:0;
        width:100%;

        text-align: center;
        color: white;
        background-color: #2d807d;
        font-family: Arial, Helvetica, sans-serif;
        padding: 5px;
        font-size: 10pt;
    }
</style>

<footer class="bawah">
    design by kelompok 2
</footer>
</body>
</html>