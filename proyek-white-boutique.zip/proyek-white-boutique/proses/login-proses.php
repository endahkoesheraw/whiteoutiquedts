<?php

session_start();

require_once '../config/db.php';

$nama 		= $_POST['nama'];
$password	= $_POST['password'];
$jabatan	= $_POST['jabatan'];

if (empty($nama) || empty($password) || empty($jabatan)) {
	echo "
	<script>
		alert('Login Gagal!');
		document.location.href= '../index.php';
	</script>
	";
}

$sql 	= "SELECT * FROM tb_users WHERE nama = '" . $nama . "' AND password = '" . $password . "' AND jabatan = '" . $jabatan . "'";
$query 	= $conn->query($sql);
$result = $query->fetch_assoc();

if ($query->num_rows > 0) {

	$_SESSION['user'] = $result['nama'];
	$_SESSION['id_user'] = $result['id'];

	if ($result['jabatan'] == 'admin') {
		$_POST["nama"] = $result['nama'];
		header('Location: ../admin/index.php');
	} else {
		header('Location: ../petugas/index.php');
	}
} else {
	echo "
	<script>
		alert('Login Gagal!');
		document.location.href= '../index.php';
	</script>
	";
}
