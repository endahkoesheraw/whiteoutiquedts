<?php
session_start();
require_once '../../config/db.php';

if (!isset($_SESSION['user'])) {
	header('Location: ../../index.php');
}

$kode_barang 	= $_POST['kode_barang'];
$nama_barang 	= $_POST['nama_barang'];
$stok_barang 	= $_POST['stok_barang'];
$jenis_barang 	= $_POST['jenis_barang'];
$harga_barang 	= $_POST['harga'];
$diskon			= $_POST['diskon'];
 
$tanggal_masuk	= $_POST['tanggal_masuk'];


if (isset($kode_barang, $nama_barang, $stok_barang, $jenis_barang,$harga_barang, $diskon,  $tanggal_masuk)) {
	header('Location: ../data-barang.php?h=tambah');
}

$sql = "INSERT INTO `tb_barang`(`id`, `kode_barang`, `nama_barang`, `stok_barang`, `jenis_barang`,`harga`, `diskon`,`tanggal_masuk`) VALUES ('', '".$kode_barang."','".$nama_barang."', '".$stok_barang."', '".$jenis_barang."', '".$harga_barang."','".$diskon."','".$tanggal_masuk."')";
$query = $conn->query($sql);

if ($query) {
	header('Location: ../data-barang.php');
} else {
	header('Location: ../data-barang.php?h=tambah');
}
