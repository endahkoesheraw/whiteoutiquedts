<?php
session_start();
require_once '../../config/db.php';

if (!isset($_SESSION['user'])) {
	header('Location: ../../index.php');
}

$id 			= $_POST['id'];
$kode_barang 	= $_POST['kode_barang'];
$nama_barang 	= $_POST['nama_barang'];
$stok_barang	= $_POST['stok_barang'];
$harga_barang	= $_POST['harga'];
$diskon			= $_POST['diskon'];
$tanggal_masuk	= $_POST['tanggal_masuk'];

$update = $conn->query("UPDATE tb_barang SET kode_barang = '".$kode_barang."', nama_barang = '".$nama_barang."', stok_barang = '".$stok_barang."', harga = '".$harga_barang."' , diskon ='".$diskon."' , tanggal_masuk = '".$tanggal_masuk."' WHERE id='".$id."'");

if ($update) {
	header('Location: ../data-barang.php');
} else {
	header('Location: ../data-barang.php?h=edit-barang&id=2');
}