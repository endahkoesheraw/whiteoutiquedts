<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,256L48,224C96,192,192,128,288,122.7C384,117,480,171,576,165.3C672,160,768,96,864,80C960,64,1056,96,1152,117.3C1248,139,1344,149,1392,154.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
	</svg>
</div>
<div class="tbh-container">
	<div class="tbh-box">
		<div class="tbh-title">
			<center>
				<h2>Tambah Data Karyawan White Boutique</h2>
			</center>
		</div>

		<hr>

		<a href="petugas-kasir.php" class="tbh-btn-kembali">&larr; Kembali</a>
		<div class="clearfix"></div>

		<form action="proses/tambah_kasir.php" method="POST" class="mt-3" autocomplete="off">
			<div class="tbh-form-group">
				<label for="nama" class="tbh-form-group-label">Nama Karyawan</label>
				<input type="text" name="nama" placeholder="Nama Petugas" class="form-control" autofocus required>
			</div>
			<div class="tbh-form-group">
				<label for="password" class="tbh-form-group-label">Password Karyawan</label>
				<input type="text" name="password" placeholder="Password Kasir" class="form-control" required>
			</div>
			<div class="tbh-form-group">
				<label for="jabatan" class="tbh-form-group-label">Jabatan</label>
				<input type="text" name="jabatan" value="kasir" class="form-control" required readonly>
			</div>
			<button type="submit" class="tbh-btn-tambah"> <b class="tbh-plus">+</b> Tambah Karyawan</button>
		</form>
	</div>
</div>