<!-- <style>
    .bawah {
        text-align: center;
        color: white;
        background-color: #2d807d;
        font-family: Arial, Helvetica, sans-serif;
        padding: 5px;
        font-size: 10pt;
        width: 100%;
    }
</style>

<footer class="bawah">
    design by kelompok 2
</footer> -->