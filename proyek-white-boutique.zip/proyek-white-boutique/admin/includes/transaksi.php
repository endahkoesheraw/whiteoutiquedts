<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,96L48,101.3C96,107,192,117,288,117.3C384,117,480,107,576,117.3C672,128,768,160,864,154.7C960,149,1056,107,1152,96C1248,85,1344,107,1392,117.3L1440,128L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
	</svg>
</div>
<div class="kar-container">
	<div class="kar-box">
		<div class="kar-title">
			<center>
				<h3>Laporan Data Transaksi White Boutique</h3>
				<center>
		</div>
		<hr>

		<div class="kar-btn">
			<a href="index.php" class="kar-btn-back">&larr; Kembali</a>
		</div>

		<div class="clear"></div>

		<table class="kar-tabel">
			<thead>
				<tr>
					<th class="kar-col-0">No</th>
					<th class="kar-col-3">Petugas</th>
					<th class="kar-col-3">Nama Barang</th>
					<th class="kar-col-3">Jumlah Barang</th>
					<th class="kar-col-3">Tanggal Transaksi</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($data_tb_transaksi as $data) : ?>
					<tr>
						<td class="kar-row"><?= $no++ ?></td>
						<td class="kar-row"><?= $data['nama'] ?></td>
						<td class="kar-row"><?= $data['nama_barang'] ?></td>
						<td class="kar-row"><?= $data['jumlah_barang'] ?></td>
						<td class="kar-row"><?= date('d/m/Y', strtotime($data['tanggal_transaksi'])) ?></td>
					</tr>
				<?php endforeach ?>
			</tbody>

		</table>

	</div>
</div>