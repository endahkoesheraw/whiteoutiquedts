<!-- halo -->
<div class="halo">
	<center>
		<div class="halo-profile-pic">
			<img src="../img/dashboard/profile-pic.png" alt="" style="border-radius: 50%;">
		</div>
		<div class="halo-name">
			<h2> <b>Hai !</b><br /> <?= $_SESSION["user"]; ?></h2>
		</div>
	</center>
</div>
<div class="halo-waves">
	<svg xmlns="../img/dashboard/wave-up.svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,256L26.7,240C53.3,224,107,192,160,192C213.3,192,267,224,320,218.7C373.3,213,427,171,480,176C533.3,181,587,235,640,218.7C693.3,203,747,117,800,106.7C853.3,96,907,160,960,165.3C1013.3,171,1067,117,1120,133.3C1173.3,149,1227,235,1280,256C1333.3,277,1387,235,1413,213.3L1440,192L1440,0L1413.3,0C1386.7,0,1333,0,1280,0C1226.7,0,1173,0,1120,0C1066.7,0,1013,0,960,0C906.7,0,853,0,800,0C746.7,0,693,0,640,0C586.7,0,533,0,480,0C426.7,0,373,0,320,0C266.7,0,213,0,160,0C106.7,0,53,0,27,0L0,0Z"></path>
	</svg>
</div>
<!-- end halo -->

<!-- box -->
<div class="box-title">
	<center>
		<h3>
			- Pilihan Menu -
		</h3>
	</center>
</div>
<div class="box">
	<div class="box-card">
		<?php
		$sql = $conn->query("SELECT (tb_barang.harga * tb_transaksi.jumlah_barang) AS Total FROM `tb_transaksi` LEFT JOIN `tb_barang` ON tb_transaksi.id_barang = tb_barang.id");
		$array_total = $sql->fetch_all(MYSQLI_ASSOC);
		$total = [];
		for ($i = 0; $i < $sql->num_rows; $i++) {
			array_push($total, $array_total[$i]['Total']);
		}
		$total_transaksi = array_sum($total);
		?>
		<div class="box-card-title">
			<h3><b>Total Transaksi</b></h3>
		</div>
		<center>
			<div class="box-card-image">
				<img src="../img/dashboard/tr-box.png" alt="ilustrasi-transaksi">
			</div>
		</center>
		<center>
			<div class="box-card-data">
				<h4>Rp. <?= number_format($total_transaksi) ?></h4>
			</div>
		</center>
		<div>
			<h4><a href="transaksi.php" class="box-card-details">Details &#8594;</a></h4>
		</div>
	</div>
	<div class="box-card">
		<?php
		$sql = $conn->query("SELECT COUNT(*) AS TotalBarang FROM tb_barang");
		$barang = $sql->fetch_assoc();
		?>
		<div class="box-card-title">
			<h3><b>Data Barang</b></h3>
		</div>
		<center>
			<div class="box-card-image">
				<img src="../img/dashboard/br-box.png" alt="ilustrasi-data barang">
			</div>
		</center>
		<center>
			<div class="box-card-data">
				<h4><?= $barang['TotalBarang'] ?></h4>
			</div>
		</center>
		<div>
			<h4><a href="data-barang.php" class="box-card-details">Details &#8594;</a></h4>
		</div>
	</div>
	<div class="box-card">
		<?php
		$sql = $conn->query("SELECT COUNT(*) AS TotalKasir FROM tb_users WHERE jabatan = 'kasir'");
		$barang = $sql->fetch_assoc();
		?>
		<div class="box-card-title">
			<h3><b>Data Karyawan</b></h3>
		</div>
		<center>
			<div class="box-card-image">
				<img src="../img/dashboard/kr-box.png" alt="ilustrasi-data karyawan">
			</div>
		</center>
		<center>
			<div class="box-card-data">
				<h4><?= $barang['TotalKasir'] ?></h4>
			</div>
		</center>
		<div>
			<h4><a href="petugas-kasir.php" class="box-card-details">Details &#8594;</a></h4>
		</div>
	</div>
</div>
<!-- end block -->

<!-- wave bottom -->
<svg xmlns="../img/dashboard/wive-down.svg" viewBox="0 0 1440 320">
	<path fill="#c7f9f8" fill-opacity="1" d="M0,256L26.7,256C53.3,256,107,256,160,250.7C213.3,245,267,235,320,208C373.3,181,427,139,480,128C533.3,117,587,139,640,160C693.3,181,747,203,800,213.3C853.3,224,907,224,960,208C1013.3,192,1067,160,1120,165.3C1173.3,171,1227,213,1280,229.3C1333.3,245,1387,235,1413,229.3L1440,224L1440,320L1413.3,320C1386.7,320,1333,320,1280,320C1226.7,320,1173,320,1120,320C1066.7,320,1013,320,960,320C906.7,320,853,320,800,320C746.7,320,693,320,640,320C586.7,320,533,320,480,320C426.7,320,373,320,320,320C266.7,320,213,320,160,320C106.7,320,53,320,27,320L0,320Z"></path>
</svg>
<!-- end wave bottom -->