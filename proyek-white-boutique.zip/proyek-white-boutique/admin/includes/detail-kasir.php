<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,229.3C672,192,768,96,864,69.3C960,43,1056,85,1152,112C1248,139,1344,149,1392,154.7L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
	</svg>
</div>
<div class="dtl-brg-container">
	<div class="dtl-brg-box">

		<center>
			<h2>Detail Data Karyawan White Boutique</h2>
		</center>
		<hr>

		<a href="petugas-kasir.php" class="tbh-btn-kembali">&larr; Kembali</a>
		<div class="clearfix"></div>

		<?php
		$sql = $conn->query("SELECT * FROM tb_users WHERE id = '" . $_GET['id'] . "'");
		$data = $sql->fetch_assoc();
		?>

		<div class="dtl-brg-box-card">
			<div class="dtl-brg-card-header">
				<h3><?= $data['nama'] ?></h3>
			</div>
			<div class="dtl-brg-card-body">
				<table>
					<tr>
						<td>Nama</td>
						<td class="equal"> : </td>
						<td> <?= $data['nama'] ?></td>
					</tr>
					<tr>
						<td>Jabatan</td>
						<td class="equal"> : </td>
						<td> <?= $data['jabatan'] ?></td>
					</tr>
				</table>
			</div>
		</div>

	</div>
</div>