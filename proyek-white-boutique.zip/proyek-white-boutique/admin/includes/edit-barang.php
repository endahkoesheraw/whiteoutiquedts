<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
	<path fill="#c7f9f8" fill-opacity="1" d="M0,96L40,90.7C80,85,160,75,240,90.7C320,107,400,149,480,170.7C560,192,640,192,720,192C800,192,880,192,960,181.3C1040,171,1120,149,1200,128C1280,107,1360,85,1400,74.7L1440,64L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z"></path>
</svg>
<div class="tbh-container">
	<div class="tbh-box">
		<div class="tbh-title">
			<center>
				<h2>Edit Data Barang White Boutique</h2>
			</center>
		</div>
		<hr>
		<a href="data-barang.php" class="tbh-btn-kembali">&larr; Kembali</a>
		<div class="clearfix"></div>

		<?php
		$sql = $conn->query("SELECT * FROM tb_barang WHERE id = '" . $_GET['id'] . "'");
		$data = $sql->fetch_assoc();
		?>

		<div class="card mt-3">
			<div class="dtl-brg-card-header">
				<h3>Edit data <?= $data['nama_barang'] ?></h3>
			</div>
			<div class="card-body">
				<form action="proses/edit-data-barang.php" method="POST">
					<div class="tbh-form-group">
						<label for="kode_barang" class="tbh-form-group-label">Kode Barang</label>
						<input type="text" name="kode_barang" value="<?= $data['kode_barang'] ?>" class="form-control" required>
					</div>
					<div class="tbh-form-group">
						<label for="nama_barang" class="tbh-form-group-label">Nama Barang</label>
						<input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>" class="form-control" required>
					</div>
					<div class="tbh-form-group">
						<label for="stok_barang" class="tbh-form-group-label">Stok Barang</label>
						<input type="number" name="stok_barang" value="<?= $data['stok_barang'] ?>" min="1" max="10000" class="form-control" required>
					</div>
					<div class="tbh-form-group">
						<label for="harga" class="tbh-form-group-label">Harga Barang</label>
						<input type="number" name="harga" value="<?= $data['harga'] ?>" class="form-control" required>
					</div>
					<div class="tbh-form-group">
						<label for="diskon" class="tbh-form-group-label">Diskon Barang</label>
						<input type="number" name="diskon" value="<?= $data['diskon'] ?>" class="form-control" required>
					</div>
					<div class="tbh-form-group">
						<label for="tanggal_masuk" class="tbh-form-group-label">Tanggal Masuk</label>
						<input type="date" name="tanggal_masuk" value="<?= $data['tanggal_masuk'] ?>" class="form-control" required>
					</div>
					<input type="hidden" name="id" value="<?= $data['id'] ?>">
					<button type="submit" class="tbh-btn-tambah">Edit Data</button>
					<div class="clearfix"></div>
				</form>
			</div>
		</div>

	</div>
</div>