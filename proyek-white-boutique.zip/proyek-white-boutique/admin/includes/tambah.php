<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,96L48,106.7C96,117,192,139,288,133.3C384,128,480,96,576,96C672,96,768,128,864,133.3C960,139,1056,117,1152,112C1248,107,1344,117,1392,122.7L1440,128L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
	</svg>
</div>
<div class="tbh-container">
	<div class="tbh-box">
		<div class="tbh-title">
			<center>
				<h2>- Tambah Data Barang White Boutique -</h2>
			</center>
		</div>
		<hr>
		<a href="data-barang.php" class="tbh-btn-kembali">&larr; Kembali</a>
		<div class="clearfix">

		</div>

		<form action="proses/tambah_barang.php" method="POST" class="mt-3" autocomplete="off">
			<div class="tbh-form-group">
				<label for="kode_barang" class="tbh-form-group-label">Kode Barang</label>
				<input type="text" name="kode_barang" placeholder="Kode Barang" class="form-control" autofocus required>
			</div>
			<div class="tbh-form-group">
				<label for="nama_barang" class="tbh-form-group-label">Nama Barang</label>
				<input type="text" name="nama_barang" placeholder="Nama Barang" class="form-control" autofocus required>
			</div>
			<div class="tbh-form-group">
				<label for="stok_barang" class="tbh-form-group-label">Stok Barang</label>
				<input type="number" name="stok_barang" placeholder="Stok Barang" min="1" max="1000" class="form-control" required>
			</div>
			<div class="tbh-form-group">
				<label for="jenis_barang" class="tbh-form-group-label">Jenis Barang</label>
				<select name="jenis_barang" class="form-control" required>
					<option value="">-- Pilih Jenis Barang --</option>
					<option value="Baju">Baju</option>
					<option value="Hijab">Hijab</option>
					<option value="Rok">Rok</option>
					<option value="Celana">Celana</option>
				</select>
			</div>
			<div class="tbh-form-group">
				<label for="harga" class="tbh-form-group-label">Harga Barang</label>
				<input type="number" name="harga" placeholder="Harga Barang" class="form-control" required>
			</div>
			<div class="tbh-form-group">
				<label for="diskon" class="tbh-form-group-label">Diskon</label>
				<input type="number" name="diskon" placeholder="Diskon Barang" class="form-control" required>
			</div>
			<div class="tbh-form-group">
				<label for="nama_barang" class="tbh-form-group-label">Tanggal Masuk</label>
				<input type="date" name="tanggal_masuk" placeholder="Tanggal Masuk" class="form-control" autofocus required>
			</div>
			<button type="submit" class="tbh-btn-tambah"> <b class="tbh-plus">+</b> Tambah Barang</button>
		</form>
	</div>
</div>