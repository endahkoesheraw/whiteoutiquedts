<?php


if (isset($_POST['cari'])) {
	include '../config/db.php';
	$keyword = $_POST['key'];

	$sql = "SELECT * FROM tb_barang WHERE 
					kode_barang LIKE '%$keyword%' OR
					nama_barang LIKE '%$keyword%' OR
					jenis_barang LIKE '%$keyword%'
	";
	$result	= mysqli_query($conn, $sql);
	$data_barang = $result->fetch_all(MYSQLI_ASSOC);
}

if (isset($_POST['filter'])) {
	include '../config/db.php';
	$tgl_awal = $_POST['tanggal_awal'];
	$tgl_akhir = $_POST['tanggal_akhir'];

	$sql = "SELECT * FROM tb_barang WHERE 
					tanggal_masuk BETWEEN '$tgl_awal' AND '$tgl_akhir'
	";
	$result	= mysqli_query($conn, $sql);
	$data_barang = $result->fetch_all(MYSQLI_ASSOC);
}

?>


<div class="wave-top">
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,192L60,176C120,160,240,128,360,138.7C480,149,600,203,720,186.7C840,171,960,85,1080,74.7C1200,64,1320,128,1380,160L1440,192L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z"></path>
	</svg>
</div>
<div class="barang">
	<div class="kon">
		<center>
			<h2>- Data Barang White Boutique -</h2>
		</center>
		<hr>

		<div class="btn">
			<button><a href="index.php" class="btn-back">&larr; Kembali</a></button>
			<button><a href="?h=tambah" class="btn-add">Tambah Barang</a></button>
		</div>
		<div class="clear"></div>

		<!-- baru -->
		<form method="POST">
			<div class="search">
				<div class="search-input">
					<input type="text" placeholder="cari disini.." class="form-control" id="inlineFormInputName" name="key" autocomplete="off" autofocus>
				</div>
				<div class="search-btn">
					<button type="submit" class="search-btn-search" name="cari" id="cari">Cari</button>
				</div>
				<div class="search-btn">
					<button type="reset" class="search-btn-reset">Reset</button>
				</div>
			</div>
		</form>


		<script>
			function tampilfilter() {
				var x = document.getElementById("date");
				if (x.style.display === "none") {
					x.style.display = "block";
				} else {
					x.style.display = "none";
				}
			}
		</script>

		<div class="date-title">
			<h4 title="click untuk menampilkan" onclick="tampilfilter()">Filter Tanggal</h4>
		</div>
		<div class="clear"></div>
		<form method="POST" id="date" style="display: none;">
			<div class="date">
				<div class="date-input-from">
					<label for="tanggal_awal">Dari Tanggal :</label>
					<input type="date" class="date-input-from-form" id="inlineFormInputName" name="tanggal_awal">
				</div>
				<div class="date-input-until">
					<label for="tanggal_akhir">Sampai Tanggal :</label>
					<input type="date" class="date-input-until-form" id="inlineFormInputGroupUsername" name="tanggal_akhir">
				</div>
				<div class="date-btn">
					<div>
						<button type="submit" name="filter" id="filter" class="date-btn-filter">Filter</button>
					</div>
					<div>
						<button type="reset" class="date-btn-reset">Reset</button>
					</div>
				</div>
			</div>
		</form>

		<!-- baru -->


		<table class="table-data">
			<thead>
				<tr>
					<th class="col-0">No</th>
					<th class="col-0">Kode Barang</th>
					<th class="col-2">Nama Barang</th>
					<th class="col-0">Stok</th>
					<th class="col-0">Jenis</th>
					<th class="col-0">Harga</th>
					<th class="col-0">Diskon(%)</th>
					<th class="col-0">Harga Setelah Diskon</th>
					<th class="col-1">Tanggal Masuk</th>
					<th class="col-2">Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($data_barang as $barang) : ?>
					<tr>
						<td><?= $no++ ?></td>
						<td><?= $barang['kode_barang'] ?></td>
						<td><?= $barang['nama_barang'] ?></td>
						<td><?= $barang['stok_barang'] ?></td>
						<td><?= $barang['jenis_barang'] ?></td>
						<td><?= $barang['harga'] ?></td>
						<td><?= $barang['diskon']  ?></td>
						<td><?= $barang['harga'] - ($barang['harga'] * $barang['diskon'] / 100)	?></td>
						<td><?= $barang['tanggal_masuk'] ?></td>
						<td>
							<div class="action">
								<a href="?h=detail&id=<?= $barang['id'] ?>" class="btn-detail">Detail</a>
								<a href="?h=edit-barang&id=<?= $barang['id'] ?>" class="btn-edit">Edit</a>
								<a href="?h=hapus&id=<?= $barang['id'] ?>" class="btn-hapus">Hapus</a>
							</div>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>