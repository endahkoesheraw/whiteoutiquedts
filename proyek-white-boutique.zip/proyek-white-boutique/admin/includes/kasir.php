<div>
	<svg xmlns="../img/dashboard/wave-up.svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,256L26.7,240C53.3,224,107,192,160,192C213.3,192,267,224,320,218.7C373.3,213,427,171,480,176C533.3,181,587,235,640,218.7C693.3,203,747,117,800,106.7C853.3,96,907,160,960,165.3C1013.3,171,1067,117,1120,133.3C1173.3,149,1227,235,1280,256C1333.3,277,1387,235,1413,213.3L1440,192L1440,0L1413.3,0C1386.7,0,1333,0,1280,0C1226.7,0,1173,0,1120,0C1066.7,0,1013,0,960,0C906.7,0,853,0,800,0C746.7,0,693,0,640,0C586.7,0,533,0,480,0C426.7,0,373,0,320,0C266.7,0,213,0,160,0C106.7,0,53,0,27,0L0,0Z"></path>
	</svg>
</div>
<div class="kar-container">
	<div class="kar-box">
		<div class="kar-title">
			<center>
				<h3>- Data Karyawan White Boutique -</h3>
			</center>
		</div>
		<hr>
		<div class="kar-btn">
			<a href="index.php" class="kar-btn-back">&larr; Kembali</a>
			<a href="?h=tambah-kasir" class="kar-btn-add">Tambah Karyawan</a>
		</div>

		<div class="clear"></div>

		<table class="kar-tabel">
			<thead>
				<tr>
					<th class="kar-col-0">No</th>
					<th class="kar-col-1">Nama Karyawan</th>
					<th class="kar-col-2">Password</th>
					<th class="kar-col-3">Jabatan</th>
					<th class="kar-col-2">Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($data_kasir as $kasir) : ?>
					<tr>
						<td class="kar-row"><?= $no++ ?></td>
						<td class="kar-row"><?= $kasir['nama'] ?></td>
						<td class="kar-row"><?= $kasir['password'] ?></td>
						<td class="kar-row"><?= $kasir['jabatan'] ?></td>
						<td class="kar-row">
							<div class="d-inline">
								<a href="?h=detail-kasir&id=<?= $kasir['id'] ?>" class="kar-btn-detail">Detail</a>
								<a href="?h=edit-kasir&id=<?= $kasir['id'] ?>" class="kar-btn-edit">Edit</a>
								<a href="?h=hapus-kasir&id=<?= $kasir['id'] ?>" class="kar-btn-hapus">Hapus</a>
							</div>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>

	</div>
</div>