<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,192L48,197.3C96,203,192,213,288,181.3C384,149,480,75,576,58.7C672,43,768,85,864,117.3C960,149,1056,171,1152,160C1248,149,1344,107,1392,85.3L1440,64L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
	</svg>
</div>
<div class="tbh-container">
	<div class="tbh-box">
		<div class="tbh-title">
			<center>
				<h2>Edit Data Karyawan White Boutique</h2>
			</center>
		</div>
		<hr>

		<a href="petugas-kasir.php" class="tbh-btn-kembali">&larr; Kembali</a>
		<div class="clearfix"></div>

		<?php
		$kasir = $conn->query("SELECT * FROM tb_users WHERE id = '" . $_GET['id'] . "'");
		$data = $kasir->fetch_assoc();
		?>

		<div class="card mt-3">
			<div class="dtl-brg-card-header">
				<h3>Edit data <?= $data['nama'] ?></h3>
			</div>
			<div class="card-body">
				<form action="proses/edit_kasir.php" method="POST" class="mt-3" autocomplete="off">
					<div class="tbh-form-group">
						<label for="nama" class="tbh-form-group-label">Nama Karyawan</label>
						<input type=" text" name="nama" value="<?= $data['nama'] ?>" class="form-control" autofocus required>
					</div>
					<div class="tbh-form-group">
						<label for="password" class="tbh-form-group-label">Password Karyawan</label>
						<input type=" text" name="password" value="<?= $data['password'] ?>" class="form-control" required readonly>
					</div>
					<div class="tbh-form-group">
						<label for="jabatan" class="tbh-form-group-label">Jabatan</label>
						<input type=" text" name="jabatan" value="<?= $data['jabatan'] ?>" class="form-control" required>
					</div>
					<input type="hidden" name="id" value="<?= $data['id'] ?>">
					<button type="submit" class="tbh-btn-tambah">Edit Karyawan</button>
				</form>
			</div>

		</div>


	</div>


</div>