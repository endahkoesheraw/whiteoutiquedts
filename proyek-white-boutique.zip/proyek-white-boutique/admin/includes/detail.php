<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,128L40,138.7C80,149,160,171,240,154.7C320,139,400,85,480,85.3C560,85,640,139,720,144C800,149,880,107,960,101.3C1040,96,1120,128,1200,138.7C1280,149,1360,139,1400,133.3L1440,128L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z"></path>
	</svg>
</div>
<div class="dtl-brg-container">
	<div class="dtl-brg-box">

		<center>
			<h2>- Detail Data Barang White Boutique -</h2>
		</center>
		<hr>

		<a href="data-barang.php" class="tbh-btn-kembali">&larr; Kembali</a>
		<div class="clearfix"></div>

		<?php
		$sql = $conn->query("SELECT * FROM tb_barang WHERE id = '" . $_GET['id'] . "'");
		$data = $sql->fetch_assoc();
		?>

		<div class="dtl-brg-box-card">
			<div class="dtl-brg-card-header">
				<h3><?= $data['nama_barang'] ?></h3>
			</div>
			<div class="dtl-brg-card-body">
				<table>
					<tr>
						<td>Stok barang</td>
						<td class="equal"> : </td>
						<td> <?= $data['stok_barang'] ?></td>
					</tr>
					<tr>
						<td>Jenis Barang</td>
						<td class="equal"> : </td>
						<td> <?= $data['jenis_barang'] ?></td>
					</tr>
					<tr>
						<td>Harga barang</td>
						<td class="equal"> : </td>
						<td> <?= $data['harga'] ?></td>
					</tr>
				</table>
			</div>
		</div>

	</div>
</div>
<div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#c7f9f8" fill-opacity="1" d="M0,192L40,192C80,192,160,192,240,202.7C320,213,400,235,480,234.7C560,235,640,213,720,202.7C800,192,880,192,960,208C1040,224,1120,256,1200,266.7C1280,277,1360,267,1400,261.3L1440,256L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z"></path>
	</svg>
</div>